import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Search, Flame, Sparkles, Scale, Check, MessageSquare, Calculator, Tag, ArrowRight, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { CatalogAnimation, FIFPriceList, Motor } from '../types';
import { api, formatRupiah } from '../services/api';
import { getMotorOtrPrice } from '../services/fifPriceList';
import {
  DEFAULT_CATALOG_ANIMATION,
  DEFAULT_CATALOG_ANIMATION_SPEED,
  isCatalogAnimation,
  normalizeCatalogAnimationSpeed,
} from '../catalogAnimation';
import { responsiveUploadImageSrcSet, responsiveUploadImageUrl } from '../utils/images';

interface CatalogSectionProps {
  motors: Motor[];
  priceList: FIFPriceList;
  animation?: CatalogAnimation;
  animationSpeed?: number;
  compareList: Motor[];
  onToggleCompare: (motor: Motor) => void;
  onOpenSimulator: (motor: Motor) => void;
  onOpenInterest: (motor: Motor) => void;
}

interface CatalogMotorImageProps {
  motor: Motor;
  animation: CatalogAnimation;
  animationSpeed: number;
  isPreviewOpen: boolean;
  onPreview: (images: string[], index: number, alt: string) => void;
}

export function getCatalogMotorImages(motor: Pick<Motor, 'image' | 'images'>) {
  return Array.from(
    new Set([...(motor.images || []), motor.image].filter((image): image is string => Boolean(image?.trim())))
  );
}

export function filterCatalogMotors(
  motors: Motor[],
  activeCategory: string,
  searchQuery: string,
  sortBy: 'default' | 'price-asc' | 'price-desc' | 'bestseller' = 'default',
) {
  return motors
    .filter((motor) => {
      const matchesCategory = activeCategory === 'Semua' || motor.category.toLowerCase().includes(activeCategory.toLowerCase());
      const matchesSearch =
        motor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        motor.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (motor.specs && motor.specs.some((spec) => spec.toLowerCase().includes(searchQuery.toLowerCase())));
      return matchesCategory && matchesSearch;
    })
    .sort((a, b) => {
      const priceA = getMotorOtrPrice(a);
      const priceB = getMotorOtrPrice(b);

      if (sortBy === 'price-asc') return priceA - priceB;
      if (sortBy === 'price-desc') return priceB - priceA;
      if (sortBy === 'bestseller') return (b.is_bestseller ? 1 : 0) - (a.is_bestseller ? 1 : 0);
      return 0;
    });
}

const CatalogMotorImage: React.FC<CatalogMotorImageProps> = ({
  motor,
  animation,
  animationSpeed,
  isPreviewOpen,
  onPreview,
}) => {
  const images = useMemo(() => getCatalogMotorImages(motor), [motor]);
  const [imageIndex, setImageIndex] = useState(0);
  const [isNearViewport, setIsNearViewport] = useState(false);
  const [imageUnavailable, setImageUnavailable] = useState(false);
  const imageButtonRef = useRef<HTMLButtonElement>(null);
  const hasImages = images.length > 0;
  const currentImage = images[imageIndex] || images[0] || motor.image;
  const cycleSpeed = normalizeCatalogAnimationSpeed(animationSpeed);
  const selectedAnimation = isCatalogAnimation(animation) ? animation : DEFAULT_CATALOG_ANIMATION;
  const animationStyle: React.CSSProperties & { '--catalog-animation-duration': string } = {
    '--catalog-animation-duration': `${Math.min(cycleSpeed * 0.3, 3)}s`,
  };

  useEffect(() => {
    setImageIndex(0);
  }, [motor.id, images.length]);

  useEffect(() => {
    setImageUnavailable(false);
  }, [currentImage]);

  useEffect(() => {
    const element = imageButtonRef.current;
    if (!element) return;
    if (!('IntersectionObserver' in window)) {
      setIsNearViewport(true);
      return;
    }

    const observer = new IntersectionObserver(([entry]) => {
      setIsNearViewport(entry.isIntersecting);
    }, { rootMargin: '200px' });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isNearViewport || images.length < 2 || isPreviewOpen || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const interval = window.setInterval(() => {
      setImageIndex((currentIndex) => (currentIndex + 1) % images.length);
    }, cycleSpeed * 1000);

    return () => window.clearInterval(interval);
  }, [cycleSpeed, images.length, isNearViewport, isPreviewOpen]);

  return (
    <button
      type="button"
      ref={imageButtonRef}
      onClick={() => {
        if (images.length > 0) {
          onPreview(images, imageIndex, motor.name);
        }
      }}
      className={`catalog-photo-frame relative h-64 w-full overflow-hidden flex items-center justify-center p-6 ${images.length > 0 ? 'cursor-zoom-in' : 'cursor-default'}`}
      aria-label={images.length > 0 ? `Lihat foto ${motor.name} ukuran penuh` : `Foto ${motor.name} belum tersedia`}
    >
      {!hasImages || imageUnavailable ? (
        <span className="px-4 text-center text-sm font-semibold text-zinc-500">Foto belum tersedia</span>
      ) : (
        <img
          key={currentImage}
          src={responsiveUploadImageUrl(currentImage, 480)}
          srcSet={responsiveUploadImageSrcSet(currentImage, [320, 400, 480])}
          sizes="(max-width: 639px) calc(100vw - 80px), (max-width: 767px) calc(100vw - 96px), (max-width: 1023px) calc(50vw - 88px), (max-width: 1279px) calc(33.333vw - 91px), 336px"
          alt={`${motor.name} foto ${imageIndex + 1}`}
          width={515}
          height={504}
          loading="lazy"
          decoding="async"
          className="catalog-photo-animation max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-500 drop-shadow-2xl"
          data-catalog-animation={selectedAnimation}
          style={animationStyle}
          onError={(event) => {
            if (event.currentTarget.src.includes('/media/')) {
              event.currentTarget.removeAttribute('srcset');
              event.currentTarget.src = currentImage;
              return;
            }
            setImageUnavailable(true);
          }}
        />
      )}
      <span className="absolute bottom-3 right-3 rounded-full bg-black/65 px-2.5 py-1 text-[10px] font-bold text-white opacity-0 transition-opacity group-hover:opacity-100">
        Klik untuk lihat foto
      </span>
      {images.length > 1 && (
        <span className="absolute bottom-3 left-3 rounded-full bg-black/65 px-2.5 py-1 text-[10px] font-bold text-white">
          {imageIndex + 1}/{images.length}
        </span>
      )}

      <div className="absolute top-4 right-4 bg-zinc-900/90 backdrop-blur-sm text-zinc-300 border border-white/10 px-3 py-1 rounded-full text-xs font-semibold">
        {motor.category}
      </div>

      {motor.is_bestseller && (
        <div
          data-testid={`motor-bestseller-${motor.id}`}
          className="absolute top-4 left-4 bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg flex items-center space-x-1"
        >
          <Flame className="w-3.5 h-3.5 fill-current" />
          <span>Bestseller</span>
        </div>
      )}
    </button>
  );
};

export const CatalogSection: React.FC<CatalogSectionProps> = ({
  motors,
  priceList,
  animation = DEFAULT_CATALOG_ANIMATION,
  animationSpeed = DEFAULT_CATALOG_ANIMATION_SPEED,
  compareList,
  onToggleCompare,
  onOpenSimulator,
  onOpenInterest,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('Semua');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc' | 'bestseller'>('default');
  const [selectedGallery, setSelectedGallery] = useState<{ images: string[]; index: number; alt: string } | null>(null);

  // Extract unique categories from actual motors data
  const categories = useMemo(() => {
    const cats = new Set<string>(['Semua']);
    motors.forEach((m) => {
      if (m.category) cats.add(m.category);
    });
    return Array.from(cats);
  }, [motors]);

  const isCompared = (motorId: string) => compareList.some((m) => m.id === motorId);

  // Filter & sort
  const filteredMotors = useMemo(
    () => filterCatalogMotors(motors, activeCategory, searchQuery, sortBy),
    [motors, activeCategory, searchQuery, sortBy],
  );

  useEffect(() => {
    const keyword = searchQuery.trim().replace(/\s+/g, ' ');
    if (keyword.length < 2) return;

    const timeoutId = window.setTimeout(() => {
      const sessionKey = 'hwa-visitor-session';
      let sessionId = sessionStorage.getItem(sessionKey);
      if (!sessionId) {
        sessionId = typeof crypto.randomUUID === 'function'
          ? crypto.randomUUID()
          : `visit_${Date.now()}_${Math.random().toString(36).slice(2)}`;
        sessionStorage.setItem(sessionKey, sessionId);
      }
      const eventId = typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID()
        : `search_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      void api.trackSearch(sessionId, keyword, eventId).catch(() => undefined);
    }, 700);

    return () => window.clearTimeout(timeoutId);
  }, [searchQuery]);

  return (
    <section id="katalog" className="py-24 bg-zinc-950 relative">
      {/* Background accents */}
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="site-accent-label inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/10 border border-red-500/20 text-red-400 text-xs font-bold uppercase tracking-wider">
            <Tag className="w-3.5 h-3.5" />
            <span>Koleksi Terlengkap</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Katalog Motor Honda
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg">
            Temukan motor Honda yang sesuai dengan kebutuhan Anda. Dari skutik lincah harian hingga motor sport impian.
          </p>
        </div>

        {/* Filter and Search Bar Controls */}
        <div className="mt-12 space-y-5">
          {/* Top row: Search and Sort */}
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
            {/* Search Input */}
            <div className="relative w-full sm:w-96">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="text"
                aria-label="Cari motor berdasarkan nama, deskripsi, atau spesifikasi"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari Beat, PCX, Vario, 160cc..."
                className="w-full pl-10 pr-4 py-2.5 bg-zinc-900/80 border border-white/10 focus:border-red-500 rounded-xl text-sm text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-red-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white text-xs"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Sort Select */}
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <span className="text-xs text-zinc-400 whitespace-nowrap">Urutkan:</span>
              <select
                aria-label="Urutkan katalog motor"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-zinc-900 border border-white/10 rounded-xl text-xs text-zinc-300 py-2.5 px-3 focus:outline-none focus:border-red-500"
              >
                <option value="default">Paling Relevan</option>
                <option value="bestseller">🔥 Terlaris / Bestseller</option>
                <option value="price-asc">Harga Terendah</option>
                <option value="price-desc">Harga Tertinggi</option>
              </select>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="hwa-auto-hide-scrollbar flex items-center gap-2 overflow-x-auto pb-2">
            {categories.map((cat) => {
              const isActive = activeCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap ${
                    isActive
                      ? 'bg-red-600 text-white shadow-lg shadow-red-900/30 border border-red-500'
                      : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-white/10'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Motorcycles Grid */}
        {filteredMotors.length === 0 ? (
          <div className="py-20 text-center">
            <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center mx-auto mb-4 text-zinc-500">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white">Tidak ada motor ditemukan</h3>
            <p className="text-zinc-400 text-sm mt-1">Coba ganti kata kunci pencarian atau kategori filter.</p>
            <button
              onClick={() => {
                setActiveCategory('Semua');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 bg-red-600 text-white text-xs font-semibold rounded-lg"
            >
              Reset Filter
            </button>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredMotors.map((motor, index) => {
              const selectedForCompare = isCompared(motor.id);

              return (
                <div
                  key={motor.id}
                  className="catalog-card group relative bg-zinc-900/50 backdrop-blur-sm border border-white/10 rounded-3xl overflow-hidden hover:border-red-500/50 transition-transform duration-500 flex flex-col justify-between"
                  style={{ animationDelay: `${index * 70}ms` }}
                >
                  {/* Glowing background on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 to-transparent rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500 pointer-events-none" />

                  {/* Top card area: image and badges */}
                  <div>
                    <CatalogMotorImage
                      motor={motor}
                      animation={animation}
                      animationSpeed={animationSpeed}
                      isPreviewOpen={Boolean(selectedGallery)}
                      onPreview={(images, index, alt) => setSelectedGallery({ images, index, alt })}
                    />

                    {/* Content area */}
                    <div className="p-6">
                      <h3 className="catalog-product-title break-words [overflow-wrap:anywhere] text-xl font-bold transition-colors">
                        {motor.name}
                      </h3>

                      <p className="catalog-product-description mt-2 break-words [overflow-wrap:anywhere] text-xs sm:text-sm">
                        {motor.description || 'Pilihan tepat untuk kenyamanan mobilitas harian Anda.'}
                      </p>

                      {/* Specs Tags */}
                      <div className="mt-4 flex flex-wrap gap-1.5">
                        {motor.specs &&
                          motor.specs.slice(0, 4).map((spec, idx) => (
                            <span
                              key={idx}
                              className="catalog-spec-tag border px-2.5 py-1 rounded-full text-[11px]"
                            >
                              {spec}
                            </span>
                          ))}
                      </div>

                      {/* Price Section */}
                      <div className="mt-6 pt-4 border-t border-white/10">
                        <span className="catalog-price-label text-[11px] uppercase tracking-wider block">
                          Mulai dari OTR Bandung
                        </span>
                        <div className="catalog-price-value text-2xl font-black mt-0.5">
                          {formatRupiah(getMotorOtrPrice(motor, priceList))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="p-6 pt-0 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      {/* Saya Tertarik */}
                      <button
                        onClick={() => onOpenInterest(motor)}
                        data-testid={`motor-interest-${motor.id}`}
                        className="catalog-cta-primary w-full py-2.5 px-3 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Saya Tertarik</span>
                      </button>

                      {/* Simulasi Kredit */}
                      <button
                        onClick={() => onOpenSimulator(motor)}
                        data-testid={`motor-simulator-${motor.id}`}
                        className="catalog-cta-secondary w-full py-2.5 px-3 font-semibold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Calculator className="w-3.5 h-3.5" />
                        <span>Simulasi Kredit</span>
                      </button>
                    </div>

                    {/* Bandingkan Button */}
                    <button
                      onClick={() => onToggleCompare(motor)}
                      data-testid={`motor-compare-${motor.id}`}
                      className={`catalog-compare-button w-full py-2 px-3 text-xs font-semibold rounded-xl flex items-center justify-center space-x-2 transition-all duration-300 ${
                        selectedForCompare
                          ? 'catalog-compare-button-active'
                          : ''
                      }`}
                    >
                      <Scale className="w-3.5 h-3.5" />
                      <span>{selectedForCompare ? '✓ Ditambahkan ke Perbandingan' : 'Bandingkan'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {selectedGallery && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
          onClick={() => setSelectedGallery(null)}
          role="dialog"
          aria-modal="true"
          aria-label={`Galeri foto ${selectedGallery.alt}`}
        >
          <div className="relative flex max-h-[92vh] max-w-5xl items-center gap-3" onClick={(event) => event.stopPropagation()}>
            {selectedGallery.images.length > 1 && (
              <button
                type="button"
                onClick={() => setSelectedGallery({ ...selectedGallery, index: (selectedGallery.index - 1 + selectedGallery.images.length) % selectedGallery.images.length })}
                className="gallery-nav-button flex h-12 w-12 shrink-0 items-center justify-center rounded-full shadow-xl transition-all duration-200"
                aria-label="Foto sebelumnya"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
            )}
            <img
              src={selectedGallery.images[selectedGallery.index]}
              alt={`${selectedGallery.alt} foto ${selectedGallery.index + 1}`}
              className="max-h-[88vh] max-w-full rounded-2xl object-contain shadow-2xl"
            />
            <button
              type="button"
              onClick={() => setSelectedGallery(null)}
              className="gallery-close-button absolute -right-2 -top-2 flex h-10 w-10 items-center justify-center rounded-full shadow-xl transition-all duration-200"
              aria-label="Tutup foto"
            >
              <X className="h-5 w-5" />
            </button>
            {selectedGallery.images.length > 1 && (
              <button
                type="button"
                onClick={() => setSelectedGallery({ ...selectedGallery, index: (selectedGallery.index + 1) % selectedGallery.images.length })}
                className="gallery-nav-button flex h-12 w-12 shrink-0 items-center justify-center rounded-full shadow-xl transition-all duration-200"
                aria-label="Foto berikutnya"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            )}
            <p className="gallery-caption absolute -bottom-8 left-0 right-0 text-center text-sm font-semibold text-white">{selectedGallery.alt} · {selectedGallery.index + 1}/{selectedGallery.images.length}</p>
          </div>
        </div>
      )}
    </section>
  );
};
